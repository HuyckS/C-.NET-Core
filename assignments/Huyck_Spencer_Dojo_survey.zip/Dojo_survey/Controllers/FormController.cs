using Microsoft.AspNetCore.Mvc;

namespace Dojo_survey.Controllers
{
    public class FormController : Controller
    {

        [HttpGet("")]
        public ViewResult Form()
        {
            return View();
        }

        [HttpPost("/result")]
        public ViewResult Result(string name, string loc, string lang, string comment)
        {
            ViewBag.FormInfo = new string[] {
                name,
                loc,
                lang,
                comment
            };
            return View();
        }
    }

}