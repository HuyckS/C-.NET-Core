using System;
using Microsoft.AspNetCore.Mvc;
using Dojo_survey.Models;

namespace Dojo_survey.Controllers
{
    public class FormController : Controller
    {

        [HttpGet("")]
        public ViewResult Form()
        {
            return View();
        }

        [HttpPost("/result")]
        public IActionResult Result(string name, string loc, string lang, string comment)
        {
            Survey FormInfo = new Survey
            {
                Name = name,
                Location = loc,
                Language = lang,
                Comment = comment
            };
            return View(FormInfo);
        }
    }

}