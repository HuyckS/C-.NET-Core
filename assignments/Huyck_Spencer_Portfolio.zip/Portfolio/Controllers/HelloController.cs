using Microsoft.AspNetCore.Mvc;

namespace Portfolio.Controllers
{
    public class HelloController : Controller
    {
        //for each route this controller is to handle:
        [HttpGet("")]     //associated route string (exclude the leading /) 
        public string Index()
        {
            return "Hello from my HelloController -- which is my 'index'.";
        }

        [HttpGet("/projects")]
        public string Projects()
        {
            return "These are my projects!";
        }

        [HttpGet("/contact")]
        public string Contact()
        {
            return "This is my Contact!";
        }
    }
}